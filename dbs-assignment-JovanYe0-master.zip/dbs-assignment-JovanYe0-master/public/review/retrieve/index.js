document.addEventListener('DOMContentLoaded', function () {
    setupFetchUserReview();
});

function setupFetchUserReview() {
    const token = localStorage.getItem('token');
    const memberId = localStorage.getItem('member_id');

    if (!token) {
        console.error('Token not found in localStorage');
        return;
    }

    if (!memberId) {
        console.error('Member ID not found in localStorage');
        return;
    }

    const fetchReviewById = (reviewId) => {
        return fetch('/reviews/single', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                reviewId: reviewId,
                memberId: memberId
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.statusText);
            }
            return response.json();
        })
        .then(body => {
            console.log('Server response:', body); // Log the entire response body for debugging

            if (body.error) throw new Error(body.error);

            const reviews = body; // The response is an array of reviews
            const review = reviews[0]; // Assuming we want the first review

            // Log the type and value of review for debugging
            console.log('Review type:', typeof review);
            console.log('Review value:', review);

            if (!review) {
                throw new Error('Review not found');
            }

            const reviewContainerDiv = document.querySelector('#review-container');
            reviewContainerDiv.innerHTML = ''; // Clear previous reviews if any

            const reviewDiv = document.createElement('div');
            reviewDiv.classList.add('review-row');

            let ratingStars = '';
            for (let i = 0; i < review.rating; i++) {
                ratingStars += '⭐';
            }

            reviewDiv.innerHTML = `
                <h3>Review ID: ${review.reviewId}</h3>
                <p>Product Name: ${review.productName}</p>
                <p>Rating: ${ratingStars}</p>
                <p>Review Text: ${review.reviewText}</p>
                <p>Review Date: ${review.reviewDate ? review.reviewDate.slice(0, 10) : ""}</p>
                <button class="update-button">Update</button>
                <button class="delete-button">Delete</button>
            `;

            reviewDiv.querySelector('.update-button').addEventListener('click', function() {
                localStorage.setItem("reviewId", review.reviewId);
                window.location.href = `/review/update`;
            });

            reviewDiv.querySelector('.delete-button').addEventListener('click', function() {
                localStorage.setItem("reviewId", review.reviewId);
                window.location.href = `/review/delete`;
            });

            reviewContainerDiv.appendChild(reviewDiv);
        })
        .catch(error => {
            console.error('Fetching review failed:', error);
        });
    };

    document.querySelector('#fetch-review-button').addEventListener('click', function() {
        const reviewId = document.querySelector('#review-id-input').value.trim();
        if (reviewId) {
            fetchReviewById(reviewId).catch(error => {
                console.error('Error fetching review:', error.message);
            });
        } else {
            console.error('Review ID is required');
        }
    });
}
