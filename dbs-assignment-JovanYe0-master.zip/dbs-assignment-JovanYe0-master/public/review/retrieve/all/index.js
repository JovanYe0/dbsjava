function fetchUserReviews() {
    const token = localStorage.getItem("token");

    if (!token) {
        console.error('Token not found in localStorage');
        return;
    }

    return fetch(`/reviews`, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        return response.json().catch(function() {
            throw new Error('Failed to parse JSON');
        });
    })
    .then(function (body) {
        console.log('Server response:', body); // Log the entire response body for debugging

        if (body.error) throw new Error(body.error);

        const reviews = body;

        // Log the type and value of reviews for debugging
        console.log('Reviews type:', typeof reviews);
        console.log('Reviews value:', reviews);

        if (!Array.isArray(reviews)) {
            throw new Error('Expected an array of reviews');
        }

        const reviewContainerDiv = document.querySelector('#review-container');
        reviewContainerDiv.innerHTML = ''; // Clear previous reviews if any

        reviews.forEach(function (review) {
            const reviewDiv = document.createElement('div');
            reviewDiv.classList.add('review-row');

            let ratingStars = '';
            for (let i = 0; i < review.rating; i++) {
                ratingStars += '⭐';
            }

            reviewDiv.innerHTML = `
                <h3>Review ID: ${review.reviewId}</h3>
                <p>Product Name: ${review.productName}</p>
                <p>Rating: ${ratingStars}</p>
                <p>Review Text: ${review.reviewText}</p>
                <p>Review Date: ${review.date ? review.date.slice(0, 10) : ""}</p>
                <button class="update-button">Update</button>
                <button class="delete-button">Delete</button>
            `;

            reviewDiv.querySelector('.update-button').addEventListener('click', function() {
                localStorage.setItem("reviewId", review.reviewId);
                window.location.href = `/review/update`;
            });

            reviewDiv.querySelector('.delete-button').addEventListener('click', function() {
                localStorage.setItem("reviewId", review.reviewId);
                window.location.href = `/review/delete`;
            });

            reviewContainerDiv.appendChild(reviewDiv);
        });
    })
    .catch(function (error) {
        console.error('Fetching reviews failed:', error);
    });
}

document.addEventListener('DOMContentLoaded', function () {
    fetchUserReviews().catch(function (error) {
        console.error('Error during DOMContentLoaded:', error);
    });
});
