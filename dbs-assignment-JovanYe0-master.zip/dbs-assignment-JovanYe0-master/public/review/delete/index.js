window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const reviewId = localStorage.getItem('reviewId');

    const form = document.querySelector('form'); // Only have 1 form in this HTML
    form.querySelector('input[name=reviewId]').value = reviewId;
    
    form.onsubmit = function (e) {
        e.preventDefault(); // prevent using the default submit behavior

        // delete review by reviewId using fetch API with method DELETE
        fetch(`/reviews/${reviewId}`, {
            method: "DELETE",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            }
        })
        .then(function (response) {
            if (response.ok) {
                alert(`Review deleted!`);
                // Optional: Redirect to another page or update the UI accordingly
                window.location.href = '/review'; // adjust the redirect URL as necessary
            } else {
                // If fail, show the error message
                response.json().then(function (data) {
                    alert(`Error deleting review - ${data.message}`);
                });
            }
        })
        .catch(function (error) {
            alert(`Error deleting review - ${error.message}`);
        });
    };
});
