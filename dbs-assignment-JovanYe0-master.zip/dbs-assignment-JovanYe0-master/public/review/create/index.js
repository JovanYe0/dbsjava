window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");
    const memberid = localStorage.getItem("member_id");
    fetch('/saleOrders', {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(body => {
        if (body.error) throw new Error(body.error);
        const saleOrders = body.saleOrders;
        const tbody = document.querySelector("#product-tbody");
        saleOrders.forEach(saleOrder => {
            const row = document.createElement("tr");
            row.classList.add("product");

            const nameCell = document.createElement("td");
            nameCell.textContent = saleOrder.name;
            row.appendChild(nameCell);

            const descriptionCell = document.createElement("td");
            descriptionCell.textContent = saleOrder.description;
            row.appendChild(descriptionCell);

            const imageUrlCell = document.createElement("td");
            imageUrlCell.innerHTML = `<img src="${saleOrder.imageUrl}" alt="Product Image">`;
            row.appendChild(imageUrlCell);

            const unitPriceCell = document.createElement("td");
            unitPriceCell.textContent = saleOrder.unitPrice;
            row.appendChild(unitPriceCell);

            const quantityCell = document.createElement("td");
            quantityCell.textContent = saleOrder.quantity;
            row.appendChild(quantityCell);

            const countryCell = document.createElement("td");
            countryCell.textContent = saleOrder.country;
            row.appendChild(countryCell);

            const orderIdCell = document.createElement("td");
            orderIdCell.textContent = saleOrder.saleOrderId;
            row.appendChild(orderIdCell);

            const orderDatetimeCell = document.createElement("td");
            orderDatetimeCell.textContent = new Date(saleOrder.orderDatetime).toLocaleString();
            row.appendChild(orderDatetimeCell);

            const statusCell = document.createElement("td");
            statusCell.textContent = saleOrder.status;
            row.appendChild(statusCell);

            const createReviewCell = document.createElement("td");
            const viewProductButton = document.createElement("button");
            viewProductButton.textContent = "Create Review";
            viewProductButton.addEventListener('click', function () {
                document.querySelector("#review-product-id").innerHTML = saleOrder.name;
                document.querySelector("input[name='productId']").value = saleOrder.productId;
                localStorage.setItem("saleOrderId", saleOrder.saleOrderId);
            });
            createReviewCell.appendChild(viewProductButton);
            row.appendChild(createReviewCell);

            tbody.appendChild(row);
        });
    })
    .catch(error => {
        console.error(error);
    });

    document.querySelector('#review-form').addEventListener('submit', async function (event) {
        event.preventDefault();
    
        const product_id = document.querySelector("input[name='productId']").value;
        const rating = document.querySelector("input[name='rating']").value;
        const review_text = document.querySelector("textarea[name='reviewText']").value;
        const member_id = localStorage.getItem('member_id'); // Assuming member_id is stored in localStorage
        const token = localStorage.getItem('token'); // Assuming token is stored in localStorage
    
        try {
            const response = await fetch('/reviews/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ member_id, product_id, rating, review_text, review_date: new Date().toISOString() })
            });
    
            const result = await response.json();
            if (response.ok) {
                alert(result.message);
            } else {
                alert(result.message); // Updated to check for `result.message` consistently
            }
        } catch (error) {
            console.error('Error submitting review:', error);
            alert('An error occurred while submitting the review.');
        }
    });
    
});
