window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');
    const reviewId = localStorage.getItem('reviewId');

    const form = document.querySelector('form'); // Select the form element
    const reviewIdInput = form.querySelector('input[name="reviewId"]'); // Select the reviewId input field
    reviewIdInput.value = reviewId; // Populate reviewId input
    form.onsubmit = function (e) {
        e.preventDefault(); // Prevent default form submission

        const rating = form.querySelector('select[name=rating]').value; // Corrected to select
        const reviewText = form.querySelector('textarea[name=reviewText]').value; // Corrected to textarea

        // Update review details by reviewId using fetch API with method PUT
        fetch(`/reviews/${reviewId}`, {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                rating: rating,
                reviewText  : reviewText
            }),
        })
        .then(function (response) {
            if (response.ok) {
                alert(`Review updated!`);
                // Clear the input fields
                form.querySelector("select[name=rating]").value = ""; // Clear rating
                form.querySelector("textarea[name=reviewText]").value = ""; // Clear reviewText
            } else {
                // If fail, show the error message
                response.json().then(function (data) {
                    alert(`Error updating review - ${data.message}`);
                });
            }
        })
        .catch(function (error) {
            alert(`Error updating review`);
        });
    };
});
