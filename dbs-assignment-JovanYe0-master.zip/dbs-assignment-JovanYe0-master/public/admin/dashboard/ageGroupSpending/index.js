window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");

    fetchAgeGroupSpending(); // Initially fetch without any query parameters

    const form = document.querySelector("form");
    const button = document.querySelector("button");

    function fetchAgeGroupSpending(bodyParams = {}) {
        fetch('/dashboard/ageGroupSpending', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify(bodyParams)
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (body) {
                if (body.error) throw new Error(body.error);

                console.log(body.spending);

                const spendings = body.spending || [];

                const tbody = document.querySelector("#spending-tbody");
                tbody.innerHTML = '';

                spendings.forEach(function (spending) {
                    const row = document.createElement("tr");

                    const ageGroupCell = document.createElement("td");
                    const totalSpendingCell = document.createElement("td");
                    const numberOfMembersCell = document.createElement("td");

                    ageGroupCell.textContent = spending.ageGroup;
                    totalSpendingCell.textContent = spending.totalSpending;
                    numberOfMembersCell.textContent = spending.memberCount;

                    row.appendChild(ageGroupCell);
                    row.appendChild(totalSpendingCell);
                    row.appendChild(numberOfMembersCell);

                    tbody.appendChild(row);
                });
            })
            .catch(function (error) {
                console.error(error);
            });
    }

    function handleFormSubmission(event) {
        event.preventDefault();

        const gender = form.elements.gender.value;
        const minTotalSpending = form.elements.minTotalSpending.value;
        const minMemberTotalSpending = form.elements.minMemberTotalSpending.value;

        const bodyParams = {
            gender,
            minTotalSpending,
            minMemberTotalSpending
        };

        fetchAgeGroupSpending(bodyParams); // Pass bodyParams to fetch function
    }

    button.addEventListener("click", handleFormSubmission);
});
