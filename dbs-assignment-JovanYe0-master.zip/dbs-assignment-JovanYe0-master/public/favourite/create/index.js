window.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem("token");
    const cartProductId = localStorage.getItem("favouriteProductId");
    const productIdInput = document.querySelector("input[name='productId']");
    productIdInput.value = cartProductId;
    const form = document.getElementById("add-to-favourite-form");
    form.onsubmit = function (e) {
        e.preventDefault();

        const productId = productIdInput.value; // Ensure this value is correct

        fetch(`/favourites`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ productId: productId }), // Ensure 'product_id' matches your backend
        })
        .then(function (response) {
            if (response.ok) {
                alert(`Product added to favourites successfully!`);
            } else {
                response.json().then(function (data) {
                    alert(`Error adding product to favourites - ${data.message}`);
                });
            }
        })
        .catch(function (error) {
            alert(`Error adding product to favourites`);
        });
    };
});
