function fetchUserFavorites() {
    const token = localStorage.getItem("token");

    if (!token) {
        console.error('Token not found in localStorage');
        return;
    }

    return fetch(`/favourites`, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    })
    .then(function (response) {
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        return response.json().catch(function() {
            throw new Error('Failed to parse JSON');
        });
    })
    .then(function (favorites) { // Assuming API returns an array of favorite objects
        console.log('Server response:', favorites); // Log the entire response body for debugging

        const favoriteContainerDiv = document.querySelector('#favorite-container');
        favoriteContainerDiv.innerHTML = ''; // Clear previous favorites if any

        favorites.forEach(function (favorite) {
            const favoriteDiv = document.createElement('div');
            favoriteDiv.classList.add('favorite-row');
        
            // Ensure favorite.unit_price exists and is a number before using .toFixed(2)
            const unitPrice = typeof favorite.unitPrice === 'number' ? `$${favorite.unitPrice}` : 'Price not available';
        
            favoriteDiv.innerHTML = `
                <h3>Favorite ID: ${favorite.favouriteId}</h3>
                <p>Product Name: ${favorite.name}</p>
                <p>Description: ${favorite.description || "N/A"}</p>
                <p>Unit Price: ${unitPrice}</p>
                <button class="delete-button">Delete</button>
            `;
        
            favoriteDiv.querySelector('.delete-button').addEventListener('click', function() {
                localStorage.setItem("favouriteId", favorite.favouriteId);
                window.location.href = `/favourite/delete`;
            });
        
            favoriteContainerDiv.appendChild(favoriteDiv);
        });
    })
    .catch(function (error) {
        console.error('Fetching favorites failed:', error);
    });
}

document.addEventListener('DOMContentLoaded', function () {
    fetchUserFavorites().catch(function (error) {
        console.error('Error during DOMContentLoaded:', error);
    });
});
