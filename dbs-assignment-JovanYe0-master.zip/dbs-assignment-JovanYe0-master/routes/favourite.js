const express = require('express');
const favouriteController = require('../controllers/favouritesController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

router.use(jwtMiddleware.verifyToken);

router.post('/', favouriteController.handleCreatefavourite);

router.get('/', favouriteController.handleShowfav);


router.delete('/:favouriteId', favouriteController.deletefav);
module.exports = router;