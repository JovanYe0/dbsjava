// See https://expressjs.com/en/guide/routing.html for routing

const express = require('express');
const reviewsController = require('../controllers/reviewsController');
const jwtMiddleware = require('../middleware/jwtMiddleware');

const router = express.Router();

// Apply jwtMiddleware to all routes in this file
router.use(jwtMiddleware.verifyToken);

// POST route to handle review submission
router.post('/create', reviewsController.handleCreateReview); // Assuming handleCreateReview is the function to handle review submission
router.get('/', reviewsController.handleShowReview);
router.put('/:reviewId', reviewsController.handleUpdateReview);
router.delete('/delete', reviewsController.deletereview);
router.post('/single', reviewsController.showsinglereview);   
module.exports = router;