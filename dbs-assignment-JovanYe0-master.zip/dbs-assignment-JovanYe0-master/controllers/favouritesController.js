const favModel = require('../models/favourites');


module.exports.handleCreatefavourite = async function (req, res) {
    const member_id = res.locals.member_id;
    const { productId } = req.body;
    try {
        await favModel.createfavourite(productId, member_id);
        res.status(200).json({ message: 'Product favourited!' });
    } catch (err) {
        if (err .message.includes("Product with id  does not exist")) {
            return res.status(400).json({ message: 'Product with id  does not exist' });
        } else if (err.message.includes("Favourite for member id and product id already exists")) {
            return res.status(400).json({ message: 'Favourite for member id and product id already exists' });
        } else if (err.message.includes('Member has not purchased the product')) {
            return res.status(400).json({ message: 'Member has not purchased the product' });
        } else {
            console.error('Error:', err.message);
            return res.status(500).json({ message: 'An error occurred while favouriting the product' });
        }
    }
}

module.exports.handleShowfav = async function(req, res) {
    const member_id = res.locals.member_id; // Assuming member_id is set in res.locals from middleware

    try {
        const favorites = await favModel.showfav(member_id);
        res.status(200).json(favorites); // Send the fetched favorites as JSON response
    } catch (err) {
        console.error('Error fetching favorites:', err.message);
        res.status(500).json({ error: 'Failed to fetch favorites' }); // Send an error response if fetching fails
    }
};
module.exports.deletefav = async function (req, res) {
    const member_id = res.locals.member_id;
    const favouriteid = req.params.favouriteId;
    try {
        await favModel.deletingfav(favouriteid, member_id);
        res.status(204).send();
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
}