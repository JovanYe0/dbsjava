const { EMPTY_RESULT_ERROR, UNIQUE_VIOLATION_ERROR, DUPLICATE_TABLE_ERROR } = require('../errors');
const reviewsModel = require('../models/reviews');


module.exports.handleCreateReview = async function (req, res) {
    const member_id = res.locals.member_id;
    const { product_id, rating, review_text } = req.body;

    try {
        // Synchronous validation
        if (product_id === undefined || rating === undefined || review_text === undefined) {
            return res.status(400).json({ message: 'All fields are required.' });
        } else if (isNaN(product_id)) {
            return res.status(400).json({ message: 'Product ID must be numeric.' });
        } else if (isNaN(rating) || rating < 1 || rating > 5) {
            return res.status(400).json({ message: 'Rating must be numeric and between 1 and 5.' });
        }

        // Asynchronous database operation
        await reviewsModel.createReview(member_id, product_id, rating, review_text);
        return res.status(200).json({ message: 'Review created successfully.' });
    } catch (error) {
        console.error('Error:', error.message);

        if (error.message.includes("Duplicate rating and review found.")) {
            return res.status(400).json({ message: 'Duplicate rating and review found.' });
        } else if (error.message === 'All fields are required.' || error.message === 'Product ID must be numeric.' || error.message === 'Rating must be numeric and between 1 and 5.') {
            return res.status(400).json({ message: error.message });
        } else {
            return res.status(500).json({ message: 'An unexpected error occurred' });
        }
    }
};



module.exports.handleShowReview = async function (req, res) {
    const member_id = res.locals.member_id;
    try {
        const reviews = await reviewsModel.getReviewByMemberId(member_id);
        res.status(200).json(reviews); // Send the fetched reviews as JSON response
    } catch (err) {
        console.error('Error fetching reviews:', err.message);
        res.status(500).json({ error: 'Failed to fetch reviews' }); // Send an error response if fetching fails
    }
}


module.exports.handleUpdateReview = async function (req, res) {
    const member_id = res.locals.member_id;
    const review_id = req.params.reviewId;
    const { rating, reviewText } = req.body;

    // Synchronous validation
    if (rating === undefined || reviewText === undefined) {
        return res.status(400).json({ message: 'All fields are required.' });
    } else if (isNaN(rating) || rating < 1 || rating > 5) {
        return res.status(400).json({ message: 'Rating must be numeric and between 1 and 5.' });
    }

    try {
        // Asynchronous database operation
        await reviewsModel.updateReview(review_id, member_id, reviewText, rating);
        return res.status(200).json({ message: 'Review updated successfully.' });
    } catch (error) {
        console.error('Error:', error.message);

        if (error.message.includes("No review found with the given review_id and member_id")) {
            return res.status(400).json({ message: 'No review found with the given review_id and member_id' });
        }else if (error.message.includes("The new review text and rating are the same as the old values. The review cannot be updated.")) {
            return res.status(400).json({ message: 'The new review text and rating are the same as the old values. The review cannot be updated.' });
        } else if (error.message === 'All fields are required.' || error.message === 'Rating must be numeric and between 1 and 5.') {
            return res.status(400).json({ message: error.message });
        } else {
            return res.status(500).json({ message: 'An unexpected error occurred' });
        }
    }
};

module.exports.deletereview = async function (req, res) {
    const member_id = res.locals.member_id;
    const review_id = req.params.reviewId;

    // Synchronous validation
    if (review_id === undefined) {
        return res.status(400).json({ message: 'Review ID is required.' });
    } else if (!isNaN(review_id)) {
        return res.status(400).json({ message: 'Review ID must be numeric.' });
    }

    try {
        // Asynchronous database operation
        await reviewsModel.deletingReview(review_id, member_id);
        return res.status(204).send();
    } catch (error) {
        console.error('Error:', error.message);

        if (error.message.includes("Review with ID for member does not exist")) {
            return res.status(400).json({ message: 'Review with ID for member does not exist' });
        } else if (error.message === 'Review ID is required.' || error.message === 'Review ID must be numeric.') {
            return res.status(400).json({ message: error.message });
        } else {
            return res.status(500).json({ message: 'An unexpected error occurred' });
        }
    }
};

module.exports.showsinglereview = async function (req, res) {
    const member_id = res.locals.member_id;
    const { reviewId } = req.body;

    // Synchronous validation
    if (reviewId === undefined) {
        return res.status(400).json({ message: 'Review ID is required.' });
    } else if (isNaN(reviewId)) {  
        return res.status(400).json({ message: 'Review ID must be numeric.' });
    }

    try {
        // Asynchronous database operation
        const reviews = await reviewsModel.getsingleReviewByMemberId(reviewId, member_id);
        return res.status(200).json(reviews); // Send the fetched reviews as JSON response
    } catch (error) {
        console.error('Error fetching reviews:', error.message);

        if (error.message === 'Review ID is required.' || error.message === 'Review ID must be numeric.') {
            return res.status(400).json({ message: error.message });
        } else {
            return res.status(500).json({ message: 'An unexpected error occurred' });
        }
    }
};
