const { query } = require('../database');

const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');

module.exports.createReview = async function(member_id, product_id, rating, review_text) {
    try {
        console.log('Review:', JSON.stringify({ member_id, product_id, rating, review_text }));
        const sql = `CALL create_review($1, $2, $3, $4)`;
        const result = await query(sql, [member_id, product_id, rating, review_text]);
        console.log(JSON.stringify(result));
        return result;
    } catch (err) {
        console.error('Error:', err.message);
        throw new Error(err.message); // Re-throw the error for the controller to handle
    }
};


module.exports.getReviewByMemberId = async function(member_id) {
    try {
        const sql = 'SELECT * FROM get_all_reviews($1)';
        const result = await query(sql, [member_id]);
        return result.rows;
    } catch (err) {
        console.error('Error retrieving reviews:', err.message);
        throw err;
    }
}


module.exports.deletingReview = async function(review_id, member_id) {
    try {
        const sql = 'CALL delete_review($1, $2)';
        await query(sql, [review_id, member_id]);
        return { message: 'Review deleted successfully' };
    } catch (err) {
        console.error('Error deleting review:', err.message);
        throw err; // Re-throw the error for the controller to handle
    }
};


module.exports.getsingleReviewByMemberId = async function(review_id, member_id) {
    try {
        const sql = 'SELECT * FROM get_reviews($1, $2)';
        const result = await query(sql, [review_id, member_id]);
        return result.rows;
    } catch (err) {
        console.error('Error retrieving reviews:', err.message);
        throw err;
    }
}

module.exports.updateReview = async function(review_id, member_id, reviewText, rating) {
    try {
        const sql = 'CALL update_review($1, $2, $3, $4)';
        const result = await query(sql, [review_id, member_id, reviewText, rating]);
        return result;
    } catch (err) {
        console.error('Error updating review:', err.message);
        throw err; // Re-throw the error for the controller to handle
    }
};
