const { query } = require('../database');

const { EMPTY_RESULT_ERROR, SQL_ERROR_CODE, UNIQUE_VIOLATION_ERROR } = require('../errors');




module.exports.createfavourite = async function (productId, member_id) {
    try {
        const sql = 'CALL add_favourites($1, $2)';
        await query(sql, [productId, member_id]);
        console.log('Favourite created successfully.');
        return { message: 'Product favourited' };
    } catch (err) {
        if (err.code === SQL_ERROR_CODE) {
            console.error('SQL Error:', err.message);
        } else if (err.code === UNIQUE_VIOLATION_ERROR) {
            console.error('Unique constraint violated:', err.message);
        } else if (err.message.includes('Member has not purchased the product')) {
            console.error('Error:', err.message);
        } else {
            console.error('Error creating favourite:', err.message);
        }
        throw err;
    }
};

module.exports.showfav = async function(member_id) {
    try {
        const sql = 'SELECT * FROM get_fav($1)';
        const result = await query(sql, [member_id]);
        return result.rows;
    } catch (err) {
        console.error('Error retrieving favorites:', err.message);
        throw err; // Propagate the error to handle it in the controller
    }
};


module.exports.deletingfav = async function(favouriteid, member_id) {
    try {
        const sql = 'CALL delete_favourite($1, $2)';
        await query(sql, [favouriteid, member_id]);
        return { message: 'Review deleted successfully' };
    } catch (err) {
        console.error('Error deleting review:', err.message);
        throw err;
    }
}
